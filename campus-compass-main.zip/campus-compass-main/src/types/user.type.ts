export type TUser = {
    name: string;
    imageUrl: string;
    email: string;
}